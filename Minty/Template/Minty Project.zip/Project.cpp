#include <Minty.h>

int main()
{
    std::cout << "Hello Minty!\n";
}